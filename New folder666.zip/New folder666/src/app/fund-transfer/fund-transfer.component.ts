import { Component, OnInit } from '@angular/core';
import { CustomerService, Transactions } from '../customer.service';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {

  isLogin:boolean=true;
  service:CustomerService;
  upBal:number;
  isTransfer:boolean=true;

  constructor(service:CustomerService) {
    this.service=service;
    this.isLogin=this.service.isLogin;
  }

  fundTransfer(data:any){
    let caccount_first=this.service.loginAccount;
    let caccount_second=data.caccount_second;
    let cbalance=data.cbalance;

    var deposit = this.service.fundTransfer(caccount_first,cbalance,caccount_second);
    deposit.subscribe((data)=> {
      this.upBal=data;
      console.log(data)
    })
    this.isTransfer=!this.isTransfer;
  }

  ngOnInit() {
  }
}
